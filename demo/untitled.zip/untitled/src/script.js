class Path2D_svg extends Path2D {
  constructor(arg) {
    super(arg);
    this._commands = [];

    if (arg instanceof Path2D_svg) {
      this._commands = [...arg._commands];
    } else if (typeof arg === "string") {
      this._commands.push({ method: "svgPath", args: [arg] });
    }
  }

  _record(method, args) {
    this._commands.push({ method, args: Array.from(args) });
  }

  moveTo(...args) { this._record("moveTo", args); return super.moveTo(...args); }
  lineTo(...args) { this._record("lineTo", args); return super.lineTo(...args); }
  bezierCurveTo(...args) { this._record("bezierCurveTo", args); return super.bezierCurveTo(...args); }
  quadraticCurveTo(...args) { this._record("quadraticCurveTo", args); return super.quadraticCurveTo(...args); }
  arc(...args) { this._record("arc", args); return super.arc(...args); }
  arcTo(...args) { this._record("arcTo", args); return super.arcTo(...args); }
  ellipse(...args) { this._record("ellipse", args); return super.ellipse(...args); }
  rect(...args) { this._record("rect", args); return super.rect(...args); }
  closePath(...args) { this._record("closePath", args); return super.closePath(...args); }

  getCommands() { return this._commands; }
}

// ==== Demo ====
const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");

// Cubic Bézier curve
let bezier = new Path2D_svg();
bezier.moveTo(20, 250);
bezier.bezierCurveTo(120, 100, 220, 400, 320, 150);
ctx.strokeStyle = "blue";
ctx.lineWidth = 2;
ctx.stroke(bezier);

console.log(bezier);
console.log("Bezier commands:", bezier, bezier.getCommands());


/*
// Circle
let circle = new Path2D_svg();
circle.arc(100, 100, 40, 0, Math.PI * 2);
ctx.strokeStyle = "red";
ctx.stroke(circle);
console.log("Circle commands:", circle.getCommands());

// Ellipse
let ellipse = new Path2D_svg();
ellipse.ellipse(250, 100, 60, 30, 0, 0, Math.PI * 2);
ctx.strokeStyle = "green";
ctx.stroke(ellipse);
console.log("Ellipse commands:", ellipse.getCommands());

// Rectangle
let rect = new Path2D_svg();
rect.rect(350, 50, 100, 80);
ctx.strokeStyle = "purple";
ctx.stroke(rect);
console.log("Rect commands:", rect.getCommands());
*/

